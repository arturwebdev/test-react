import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchUsers = createAsyncThunk(
    'users/fetchUsers',
    async function() {
        const responseUsers = await axios.get('https://jsonplaceholder.typicode.com/users')
        const dataUsers = responseUsers.data
        
        const responsePosts = await axios.get('https://jsonplaceholder.typicode.com/photos?_limit=500')
        const dataPosts = responsePosts.data

        // console.log(dataUsers[0]);
        // console.log(dataPosts[0]);

        const data = dataUsers.map(user => ({
            id: user.id,
            name: user.name,
            email: user.email.toLowerCase(),
            username: user.username.toLowerCase(),
            password: user.address.city.toLowerCase(),
            disc: user.company.catchPhrase,
            posts: [
                ...dataPosts.filter(post => post.albumId === user.id)
                             .map(post => ({
                                 id: post.id,
                                 username: user.username.toLowerCase(),
                                 disc: post.title.slice(post.title.indexOf(' ') + 1),
                                 img: post.url,
                                 comments: []
                             }))
            ]
        }))

        // console.log(data[0]);
        return data
    }
)