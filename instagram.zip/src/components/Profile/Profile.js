import React, { useEffect } from 'react'
import './Profile.css'
import { IoAppsSharp } from 'react-icons/io5'
import { useSelector } from 'react-redux'
import { selectUsers } from '../../store/slices/users/usersSlice'
import { useNavigate } from 'react-router-dom'

const Profile = () => {
  const {currentUser} = useSelector(selectUsers)
  const navigate = useNavigate()
  useEffect(() => {
    if (!currentUser.id) {
      navigate('/')
    }
  }, [currentUser])
  return (
    <div className='profile'>
      <div className='profile-container'>
        <div className='profile-header'>
          <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png' alt='img' className='prof-img' />
          <div className='prof-info'>
            <div className='prof-nickname'>
              {currentUser.username}
            </div>
            <div className='prof-followers'>
              <span><b>3</b> публикации</span>
              <span><b>342</b> подписчика</span>
              <span><b>78</b> подписок</span>
            </div>
            <div className='prof-name'>
              <span><b>{currentUser.name}</b></span>
              <span>{currentUser.disc}</span>
            </div>
          </div>
        </div>
        <div className='public'>
          <div className='public-header'>
            <div>
              <IoAppsSharp className='app-icon' />публикации
            </div>
          </div>
          <div className='public-gallery'>
              
              {
              currentUser.posts?.map(el => <a key={el.id} href='true'><img src={el.img} alt='img' /></a>)
              }
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile